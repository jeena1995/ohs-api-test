package com.order.service;

import com.google.protobuf.StringValue;
import com.order.grpc.UserServiceClient;
import com.order.model.Customer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import user.*;
import io.grpc.stub.StreamObserver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.beans.ConstructorProperties;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class UserServiceImpl extends UserServiceGrpc.UserServiceImplBase {
    @Autowired
    UserServiceClient userClient ;


    //public UserServiceImpl(Customer customer){
        //this.createUser(customer);
    //}

    //
    public void createUser(Customer customer, StreamObserver<User.UserResponse> responseObserver) {


        User.ShippingAddress address = User.ShippingAddress.newBuilder()
                .setAddress(StringValue.of(customer.getAddress()))
                .setCountry(StringValue.of(customer.getCountry()))
                .build();

        List<User.PaymentMethod> paymentMethods = customer.getPaymentMethods().stream()
                .map(pm -> User.PaymentMethod.newBuilder()
                        .setCreditCardNumber(pm.getCreditCardNumber())
                        .setCreditCardType(pm.getCreditCardType())
                        .build())
                .collect(Collectors.toList());

        User.UserResponse response = userClient.createUser(User.CreateUserRequest.newBuilder()
                .setFullName(StringValue.of(customer.getFullName()))
                .setEmail(customer.getEmail())
                .setAddress(address)
                .addAllPaymentMethods(customer.getPaymentMethods())
                .setPassword(StringValue.of(customer.getPassword()))
                .build());
        System.out.println(response.toString());
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}


