package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import user.User;
import user.UserServiceGrpc;

@Configuration
@ComponentScan("com.order")
public class UserServiceClient {

    private final UserServiceGrpc.UserServiceBlockingStub blockingStub;

    public UserServiceClient() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8082)
                .usePlaintext()
                .build();
        blockingStub = UserServiceGrpc.newBlockingStub(channel);
    }

    public User.UserResponse createUser(User.CreateUserRequest request) {
        User.UserResponse response = blockingStub.createUser(request);
        return response;
    }
}

