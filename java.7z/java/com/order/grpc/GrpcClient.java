package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import order.OrderServiceGrpc;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import product.ProductServiceGrpc;
import supplier.SupplierServiceGrpc;
import user.UserServiceGrpc;

@Configuration
public class GrpcClient {
    @Bean
    public UserServiceGrpc.UserServiceBlockingStub userServiceStub() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();
        return UserServiceGrpc.newBlockingStub(channel);
    }

    @Bean
    public OrderServiceGrpc.OrderServiceBlockingStub orderServiceStub() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();
        return OrderServiceGrpc.newBlockingStub(channel);
    }

    @Bean
    public ProductServiceGrpc.ProductServiceBlockingStub productServiceStub() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();
        return ProductServiceGrpc.newBlockingStub(channel);
    }

    @Bean
    public SupplierServiceGrpc.SupplierServiceBlockingStub supplierServiceStub() {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();
        return SupplierServiceGrpc.newBlockingStub(channel);
    }
}
