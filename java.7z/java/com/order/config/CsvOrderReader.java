package com.order.config;

import com.opencsv.bean.CsvToBeanBuilder;
import com.order.model.Customer;
import org.springframework.batch.item.ItemReader;
import org.springframework.stereotype.Component;

import java.io.FileReader;
import java.util.List;

@Component
public class CsvOrderReader implements ItemReader<Customer> {

        private final List<Customer> orders;

        public CsvOrderReader() throws Exception {
            this.orders = new CsvToBeanBuilder<Customer>(new FileReader("ohs-api-test/bootstrap/integration/order-integration.csv"))
                    .withType(Customer.class)
                    .build()
                    .parse();
        }

        @Override
        public Customer read() throws Exception {
            if (!orders.isEmpty()) {
                return orders.remove(0);
            }
            return null; // End of file
        }
    }

