package com.order.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.order.model.ProcessedOrder;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.List;

@Component
public class JsonOrderWriter implements ItemWriter<ProcessedOrder> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void write(List<? extends ProcessedOrder> orders) throws Exception {
        objectMapper.writeValue(new File("processed-orders.json"), orders);
    }
}

