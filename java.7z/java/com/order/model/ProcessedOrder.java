package com.order.model;

import lombok.Data;

@Data
public class ProcessedOrder {
    private String userPid;
    private String orderPid;
    private String supplierPid;
}