package com.order.model;

import com.opencsv.bean.CsvBindByName;
import lombok.Data;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import user.User;

import java.util.List;

@Data
public class Customer {
    @CsvBindByName
    private String email;
    @CsvBindByName
    private String fullName;
    @CsvBindByName
    private String address;
    @CsvBindByName
    List<User.PaymentMethod> paymentMethods;
    @CsvBindByName
    private String password;
    @CsvBindByName
    private String country;
    @CsvBindByName
    private String productPid;

}