import com.google.protobuf.StringValue;
import com.order.config.BatchConfig;
import com.order.model.Customer;
import com.order.service.UserServiceImpl;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;
import org.jooq.meta.derby.sys.Sys;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import user.User;

import java.io.IOException;
import java.util.Collections;
import java.util.stream.Collectors;

public class GrpcServer {
    public static void main(String[] args) throws IOException, InterruptedException {

        // Initialize Spring ApplicationContext
        System.out.println("before to start");
        /* ApplicationContext context = new AnnotationConfigApplicationContext(OrderIntegrationApplication.class);
        System.out.println("About to start");
        // Get JobLauncher and Job beans from the context
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        Job job = context.getBean("importUserJob", Job.class);

        try {
            // Launch the batch job
            jobLauncher.run(job, new JobParametersBuilder().toJobParameters());
        } catch (Exception e) {
            e.printStackTrace();
        }

         */
        Customer customer = new Customer();
        customer.setFullName("Test Name");
        customer.setPassword("test_password");
        customer.setEmail("Test email");
        customer.setAddress("Test address");
        customer.setProductPid("Test product");
        customer.setCountry("test");
        customer.setPaymentMethods(Collections.singletonList(User.PaymentMethod.newBuilder()
                .setCreditCardType(StringValue.of("test"))
                .setCreditCardNumber(StringValue.of("123"))
                .build())
        );

        Server server = ServerBuilder.forPort(8080)
                .addService(new UserServiceImpl())
                .build();

        server.start();
        System.out.println("Server started at " + server.getPort());
        server.awaitTermination();
    }
}

