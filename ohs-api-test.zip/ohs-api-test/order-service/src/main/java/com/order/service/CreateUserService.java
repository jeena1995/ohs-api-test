package com.order.service;

import com.google.protobuf.StringValue;
import com.order.grpc.OrderServiceClient;
import com.order.grpc.UserServiceClient;
import com.order.model.Customer;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.beans.factory.annotation.Autowired;
import user.User;
import user.UserServiceGrpc;

import java.util.Collections;
import java.util.UUID;

/**
 * gRPC service implementation for creating users.
 * Implements methods to handle user creation requests and process responses.
 */
@GrpcService
public class CreateUserService extends UserServiceGrpc.UserServiceImplBase {

    @Autowired
    UserServiceClient userServiceClient;

    @Autowired
    OrderServiceClient orderServiceClient;

    public String userPid;

    /**
     * Creates a user using the provided customer information asynchronously.
     * @param row The customer information used to create the user.
     */
    public void createUser(Customer row) {
        // Define a StreamObserver to handle the asynchronous user creation response
        StreamObserver<User.UserResponse> responseObserver = new StreamObserver<User.UserResponse>() {
            @Override
            public void onNext(User.UserResponse userResponse) {
                System.out.println("Response: " + userResponse.getPid());
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("Completed");
            }
        };
        // Build ShippingAddress and PaymentMethod objects from the customer information
        User.ShippingAddress address = User.ShippingAddress.newBuilder()
                .setAddress(StringValue.of(row.getShipping_address()))
                .setCountry(StringValue.of(row.getCountry()))
                .build();

        User.PaymentMethod paymentMethods = User.PaymentMethod.newBuilder()
                .setCreditCardNumber(StringValue.of(row.getCredit_card_number()))
                .setCreditCardType(StringValue.of(row.getCredit_card_type()))
                .build();

        // Create a CreateUserRequest with the customer information and send it asynchronously
        User.CreateUserRequest request = User.CreateUserRequest.newBuilder()
                .setFullName(StringValue.of(row.getFull_name()))
                .setEmail(row.getEmail())
                .setAddress(address)
                .addAllPaymentMethods(Collections.singleton(paymentMethods))
                .setPassword(StringValue.of(UUID.randomUUID().toString()))
                .build();

        createUser(request,responseObserver );

    }

    /**
     * Handles a gRPC request to create a user.
     * @param request The request object containing user creation details.
     * @param responseObserver The response observer to send back the user creation response.
     */
    @Override
    public void createUser(User.CreateUserRequest request, StreamObserver<User.UserResponse> responseObserver) {
        // Call the UserServiceClient to create a user and retrieve the response
        User.UserResponse userResponse = userServiceClient.createUser(request);
            this.userPid = userResponse.getPid();

        // Send the response back to the client
        responseObserver.onNext(userResponse);
        responseObserver.onCompleted();
    }
    /**
     * Retrieves the user PID of the last created user.
     * @return The user PID of the last created user.
     */
    public String getUserPid(){
        return this.userPid;
    }


}
