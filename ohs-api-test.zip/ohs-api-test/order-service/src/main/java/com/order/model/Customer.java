package com.order.model;


import lombok.Data;

/**
 * Model class representing a user.
 * Provides data fields corresponding to customer information.
 */
@Data
public class Customer {
    private String email;                // User's email address
    private String full_name;            // User's full name
    private String shipping_address;     // User's shipping address
    private String credit_card_number;   // User's credit card number
    private String credit_card_type;     // Type of credit card (e.g., Visa, MasterCard)
    private String country;              // User's country
    private String product_pid;          // Product ID
    private String quantity;             // Quantity of the product
    private String first_name;           // User's first name
    private String last_name;            // User's last name
    private String supplier_pid;         // Supplier ID
    private String order_id;             // Order ID
    private String date_created;         // Date when the order was created
    private String order_status;         // Status of the order

}