package com.order.model;

import lombok.Data;

/**
 * Model class representing a processed order.
 * Provides data fields corresponding to processed order information.
 */
@Data
public class ProcessedOrder {
    private String userPid;     // User ID associated with the order
    private String orderPid;    // Order ID
    private String supplierPid; // Supplier ID associated with the order
}