package com.order.service;

import com.google.protobuf.StringValue;
import com.order.grpc.OrderServiceClient;
import com.order.model.Customer;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;
import order.CreateOrderRequest;
import order.OrderResponse;
import order.OrderServiceGrpc;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * gRPC service implementation for creating orders.
 * Implements methods to handle order creation requests and process responses.
 */
@GrpcService
public class CreateOrderService extends OrderServiceGrpc.OrderServiceImplBase {

    private String orderId;
    private OrderResponse response;

    @Autowired
    OrderServiceClient orderServiceClient;

    /**
     * Handles a gRPC request to create an order.
     * @param request The request object containing order details.
     * @param responseObserver The response observer to send back the order response.
     */
    @Override
    public void createOrder(CreateOrderRequest request, StreamObserver<OrderResponse> responseObserver) {
        // Call the OrderServiceClient to create an order synchronously
        this.response  = orderServiceClient.createOder(request);
        // Send the response back to the client
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Creates an order asynchronously using provided customer information and user ID.
     * @param row The user information to create an order.
     * @param userId The ID of the user placing the order.
     */
    public  void createOrder(Customer row, String userId) {
        // Define a StreamObserver to handle the asynchronous order creation response
        StreamObserver<OrderResponse> orderResponse = new StreamObserver<OrderResponse>() {
            @Override
            public void onNext(OrderResponse orderResponse) {
                System.out.println("Response: " + orderResponse.getPid());
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
            }

            @Override
            public void onCompleted() {
                System.out.println("Completed");
            }
        };

        // Build a CreateOrderRequest using user information and send it asynchronously
        order.Product product = order.Product.newBuilder()
                .setPid(row.getProduct_pid())
                .setQuantity(Integer.parseInt(row.getQuantity()))
                .setPricePerUnit(30.00)
                .build();

        // Call the createOrder method asynchronously
        createOrder(CreateOrderRequest.newBuilder()
                .setUserPid(userId)
                .setDateCreated(StringValue.of(row.getDate_created()))
                .setDateDelivered(StringValue.of(row.getDate_created()))
                .setStatus(order.OrderStatus.valueOf(row.getOrder_status()))
                .setPricePerUnit(33.00f)
                .setQuantity(1)
                .setProducts(0 ,product)
                .build(), orderResponse);

    }
    /**
     * Retrieves the OrderResponse received from the OrderServiceClient.
     * @return The OrderResponse object received.
     */
    public OrderResponse getOrderResponse(){
        return response;
    }
}


