package com.order;

import com.order.service.CreateOrderService;
import com.order.service.CreateUserService;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.io.IOException;

public class GrpcServer {
    public static void main(String[] args) throws IOException, InterruptedException {

        // Initialize Spring ApplicationContext
        ApplicationContext context = new AnnotationConfigApplicationContext(OrderHandlingApplication.class);
        // Get JobLauncher and Job beans from the context
        JobLauncher jobLauncher = context.getBean(JobLauncher.class);
        Job job = context.getBean("importUserJob", Job.class);

        try {
            // Launch the batch job
            jobLauncher.run(job, new JobParametersBuilder().toJobParameters());
        } catch (Exception e) {
            e.printStackTrace();
        }

        Server server = ServerBuilder.forPort(9091)
                .addService(new CreateUserService())
                .addService(new CreateOrderService())
                .build()
                .start();

        System.out.println("Server started at " + server.getPort());
        server.awaitTermination();
    }
}