package com.order.service;

import com.order.model.Customer;
import com.order.model.ProcessedOrder;
import org.springframework.batch.item.ItemProcessor;

/**
 * Processor class to process User data into ProcessedOrder objects.
 * Implements Spring Batch ItemProcessor interface.
 */
public class OrderProcessor implements ItemProcessor<Customer, ProcessedOrder> {

        private final CreateUserService createUserService;

        private final CreateOrderService createOrderService;

        /**
         * Constructor to initialize OrderProcessor with required services.
         * @param createUserService Service to create users.
         * @param createOrderService Service to create orders.
         */
        public OrderProcessor(CreateUserService createUserService, CreateOrderService createOrderService) {
            this.createUserService = createUserService;
            this.createOrderService = createOrderService;

        }

        /**
         * Process method to transform Customer data into ProcessedOrder.
         * @param row Customer object containing order details.
         * @return ProcessedOrder object representing the processed order.
         * @throws Exception If an error occurs during processing.
         */
        @Override
        public ProcessedOrder process(Customer row) throws Exception {
            // Create a user based on customer information
            createUserService.createUser(row);

            // Create an order using customer information and user PID
            createOrderService.createOrder(row, createUserService.getUserPid());

            // Create a ProcessedOrder object with relevant information
            ProcessedOrder processedOrder = new ProcessedOrder();
            processedOrder.setUserPid(createUserService.getUserPid());
            processedOrder.setOrderPid(createOrderService.getOrderResponse().getPid());
            processedOrder.setSupplierPid(String.valueOf(row.getSupplier_pid()));

            return processedOrder;
        }
    }