package com.order.batch;

import com.order.model.ProcessedOrder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.batch.item.ItemWriter;
import org.springframework.core.io.FileSystemResource;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.List;

/**
 * ItemWriter implementation that writes ProcessedOrder objects to a JSON file.
 */
public class JsonFileItemWriter implements ItemWriter<ProcessedOrder> {

    private final FileSystemResource fileResource;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Constructor for JsonFileItemWriter.
     * @param fileResource The file resource where ProcessedOrder objects will be written.
     */
    public JsonFileItemWriter(FileSystemResource fileResource) {
        this.fileResource = fileResource;
    }

    /**
     * Writes a list of ProcessedOrder items to a JSON file.
     * @param items List of ProcessedOrder objects to be written.
     * @throws Exception If an error occurs during writing.
     */
    @Override
    public void write(List<? extends ProcessedOrder> items) throws Exception {
        try (OutputStream outputStream = Files.newOutputStream(fileResource.getFile().toPath())) {
            for (ProcessedOrder item : items) {
                outputStream.write(objectMapper.writeValueAsBytes(item));
                outputStream.write("\n".getBytes());
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to write items to JSON file", e);
        }
    }
}
