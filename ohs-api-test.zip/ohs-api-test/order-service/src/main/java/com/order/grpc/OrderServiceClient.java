package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import order.CreateOrderRequest;
import order.Order;
import order.OrderResponse;
import order.OrderServiceGrpc;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import user.User;
import user.UserServiceGrpc;

/**
 * gRPC client for interacting with the OrderService.
 * Provides methods to call remote gRPC services defined in the OrderService.
 */
@Configuration
public class OrderServiceClient {

    private final OrderServiceGrpc.OrderServiceBlockingStub blockingStub;

    /**
     * Constructor for OrderServiceClient.
     * Initializes the gRPC channel and the blocking stub for synchronous calls to the OrderService.
     */
    public OrderServiceClient() {
        // Create a gRPC channel to communicate with the server at localhost on port 50053
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50053)
                .usePlaintext()
                .build();
        // Create a blocking stub using the channel
        blockingStub = OrderServiceGrpc.newBlockingStub(channel);
    }

    /**
     * Creates an order by sending a CreateOrderRequest to the OrderService.
     * @param orderRequest The request object containing order details.
     * @return The response from the OrderService containing order confirmation details.
     */
    public OrderResponse createOder(CreateOrderRequest orderRequest) {
        // Make a synchronous call to the createOrder method of the OrderService
        OrderResponse response = blockingStub.createOrder(orderRequest);
        return response;
    }


}