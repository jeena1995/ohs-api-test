package com.order.config;

import com.order.batch.JsonFileItemWriter;
import com.order.model.Customer;
import com.order.model.ProcessedOrder;
import com.order.service.CreateOrderService;
import com.order.service.CreateUserService;
import com.order.service.OrderProcessor;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import javax.annotation.PostConstruct;
import java.io.IOException;


/**
 * Batch configuration class for setting up Spring Batch jobs and steps.
 */

@Configuration
@EnableBatchProcessing
public class BatchConfig {

    private final JobLauncher jobLauncher;
    private final JobBuilderFactory jobBuilderFactory;
    private final StepBuilderFactory stepBuilderFactory;
    private final CreateUserService createUserService;
    private final CreateOrderService createOrderService;

    /**
     * Constructor for BatchConfig class.
     *
     * @param jobBuilderFactory Factory for creating Job instances.
     * @param stepBuilderFactory Factory for creating Step instances.
     * @param createUserService Service for creating users.
     * @param createOrderService Service for creating orders.
     */
    public BatchConfig(JobLauncher jobLauncher, JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory, CreateUserService createUserService, CreateOrderService createOrderService) {
        this.jobLauncher = jobLauncher;
        this.jobBuilderFactory = jobBuilderFactory;
        this.stepBuilderFactory = stepBuilderFactory;
        this.createUserService = createUserService;
        this.createOrderService = createOrderService;
    }

    /* @PostConstruct
    public void checkResource() {
        System.out.println("Resource: " + inputFile);
        try {
            System.out.println("Resource exists: " + inputFile.exists());
            if (inputFile.exists()) {
                System.out.println("Resource URL: " + inputFile.getURL());
                System.out.println("Resource file path: " + inputFile.getFile().getAbsolutePath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     */

    /**
     * Bean definition for the FlatFileItemReader to read Customer data from a CSV file.
     * @return Configured FlatFileItemReader instance.
     */
    @Bean
    public FlatFileItemReader<Customer> reader() {
        return new FlatFileItemReaderBuilder<Customer>()
                .name("customerItemReader")
                .resource(new ClassPathResource("order-integration.csv"))
                .delimited()
                .delimiter(",")
                .names(new String[]{"first_name","last_name","email","supplier_pid","credit_card_number","credit_card_type","order_id","product_pid","shipping_address","country","date_created","quantity","full_name","order_id","order_status"})
                .fieldSetMapper(new BeanWrapperFieldSetMapper<Customer>() {{
                    setTargetType(Customer.class);
                }})
                .linesToSkip(1)
                .build();
    }
    /**
     * Bean definition for the ItemProcessor to process Customer data into ProcessedOrder data.
     * @return Configured ItemProcessor instance.
     */
    @Bean
    public ItemProcessor<Customer, ProcessedOrder> processor() {
        return new OrderProcessor(this.createUserService,this.createOrderService);
    }

    /**
     * Bean definition for the ItemWriter to write ProcessedOrder data to a JSON file.
     * @return Configured JsonFileItemWriter instance.
     */
    @Bean
    public ItemWriter<ProcessedOrder> itemWriter() {
        return new JsonFileItemWriter(new FileSystemResource("/processed-orders.json"));
    }

    /**
     * Bean definition for the Job to import user data.
     * @param listener Job completion listener.
     * @param step1 The step to be executed as part of the job.
     * @return Configured Job instance.
     */
    @Bean
    public Job importUserJob(JobCompletionNotificationListener listener, Step step1) {
        return jobBuilderFactory.get("importUserJob")
                .listener(listener)
                .flow(step1)
                .end()
                .build();
    }

    /**
     * Bean definition for the Step to read, process, and write data.
     * @param reader The ItemReader to read Customer data.
     * @param processor The ItemProcessor to process Customer data.
     * @param itemWriter The ItemWriter to write ProcessedOrder data.
     * @return Configured Step instance.
     */
    @Bean
    public Step step1(ItemReader<Customer> reader, ItemProcessor<Customer, ProcessedOrder> processor,
                      ItemWriter<ProcessedOrder> itemWriter) {
        return stepBuilderFactory.get("step1")
                .<Customer, ProcessedOrder>chunk(10)
                .reader(reader)
                .processor(processor)
                .writer(itemWriter)
                .build();
    }
}
