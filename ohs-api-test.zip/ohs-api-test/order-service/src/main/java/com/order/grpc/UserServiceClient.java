package com.order.grpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import user.User;
import user.UserServiceGrpc;

/**
 * gRPC client for interacting with the UserService.
 * Provides methods to call remote gRPC services defined in the UserService.
 */
@Configuration
@ComponentScan("com.order")
public class UserServiceClient {

    private final UserServiceGrpc.UserServiceBlockingStub blockingStub;

    /**
     * Constructor for UserServiceClient.
     * Initializes the gRPC channel and the blocking stub for synchronous calls to the UserService.
     */
    public UserServiceClient() {
        // Create a gRPC channel to communicate with the server at localhost on port 50054
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50054)
                .usePlaintext()
                .build();
        // Create a blocking stub using the channel
        blockingStub = UserServiceGrpc.newBlockingStub(channel);
    }

    /**
     * Creates a user by sending a CreateUserRequest to the UserService.
     * @param request The request object containing user details.
     * @return The response from the UserService containing user confirmation details.
     */
    public User.UserResponse createUser(User.CreateUserRequest request) {
        // Make a synchronous call to the createUser method of the UserService
        User.UserResponse response = blockingStub.createUser(request);
        return response;
    }
}