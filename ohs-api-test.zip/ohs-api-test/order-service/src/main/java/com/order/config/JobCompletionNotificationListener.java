package com.order.config;

import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

/**
 * Listener for monitoring the lifecycle of a batch job.
 * Implements the JobExecutionListener interface to handle job execution events.
 */
@Component
public class JobCompletionNotificationListener implements JobExecutionListener {

    /**
     * Callback method invoked before a job starts.
     * @param jobExecution The JobExecution instance representing the job about to start.
     */
    @Override
    public void beforeJob(JobExecution jobExecution) {
        System.out.println("Job Started: " + jobExecution.getJobInstance().getJobName());
    }

    /**
     * Callback method invoked after a job ends.
     * @param jobExecution The JobExecution instance representing the job that just ended.
     */
    @Override
    public void afterJob(JobExecution jobExecution) {
        System.out.println("Job Ended: " + jobExecution.getJobInstance().getJobName());
    }
}

